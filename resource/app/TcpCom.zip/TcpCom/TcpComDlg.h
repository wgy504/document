// TcpComDlg.h : header file
//

#if !defined(AFX_TCPCOMDLG_H__E7326230_BD3B_4B3E_B1C8_9E5E76080482__INCLUDED_)
#define AFX_TCPCOMDLG_H__E7326230_BD3B_4B3E_B1C8_9E5E76080482__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CTcpComDlg dialog

class CTcpComDlg : public CDialog
{
// Construction
public:
	CTcpComDlg(CWnd* pParent = NULL);	// standard constructor
	
// Dialog Data
	//{{AFX_DATA(CTcpComDlg)
	enum { IDD = IDD_TCPCOM_DIALOG };
	CButton	m_c0x;
	CButton	m_cSingle;
	CEdit	m_cPort;
	CIPAddressCtrl	m_cIPAdd;
	CButton	m_cHex;
	CEdit	m_cComData;
	CEdit	m_cNetData;
	CComboBox	m_cCom;
	CComboBox	m_cBaudRate;
	CButton	m_cBnOpen;
	CString	m_vComStatus;
	CString	m_vNetData;
	CString	m_vComData;
	CString	m_vComDataLen;
	CString	m_vPort;
	CString	m_vNetStatus;
	CString	m_vNetDataLen;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTcpComDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CTcpComDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	virtual void OnCancel();
	virtual void OnOK();
	afx_msg void OnSelchangeComboCom();
	afx_msg void OnSelchangeComboBaudrate();
	afx_msg void OnOpen();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnCheckHex();
	afx_msg void OnCHECK0x();
	afx_msg void OnCheckSg();
	afx_msg void OnClear();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnButton1();
	//}}AFX_MSG
	char EI_cOpenCom();
	char EI_cTCPOpen();
	void EI_vSysInit();
	void EI_vWriteDataToFile(char* sData,DWORD dwDataLenght,DWORD dwRecvDataLenght,bool bFlag);
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TCPCOMDLG_H__E7326230_BD3B_4B3E_B1C8_9E5E76080482__INCLUDED_)
