// TcpComDlg.cpp : implementation file
//

#include "stdafx.h"
#include "TcpCom.h"
#include "TcpComDlg.h"
#include "Serial.h"
#include <time.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

CSerial objSerial;
SOCKET  SockClient; 

char	gacCom[5]				= "COM3";
int		giBaudRate				= 115200;
bool	gbComOpenFlag			= false;
//UINT	guiComTimer				= 1;
//UINT	guiNetTimer				= 2;
LONG	glRecvComDataLen		= 0;
LONG	glRecvNetDataLen		= 0;

bool    gbSystemRunFlag			= false;
bool    gbSockClientConnectFlag = false;
bool    gbSockServerListenFlag  = false;
bool	bFirstRunFlag			= false;
bool	gbSocketRecReopenFlag	= false;
#define	COM_TIMER			1
#define	NET_TIMER			2
#define	SERVER_TIMER		3
#define	CHECK_TIMER			4

#define	CLIENT_RECV_TIME	100
#define	SERVER_RECV_TIME	100

#define	COM_DATA			FALSE
#define	NET_DATA			TRUE
/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTcpComDlg dialog

CTcpComDlg::CTcpComDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CTcpComDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTcpComDlg)
	m_vComStatus = _T("");
	m_vNetData = _T("");
	m_vComData = _T("");
	m_vComDataLen = _T("");
	m_vPort = _T("");
	m_vNetStatus = _T("");
	m_vNetDataLen = _T("");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CTcpComDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTcpComDlg)
	DDX_Control(pDX, IDC_CHECK_0x, m_c0x);
	DDX_Control(pDX, IDC_CHECK_SG, m_cSingle);
	DDX_Control(pDX, IDC_EDIT_PORT, m_cPort);
	DDX_Control(pDX, IDC_IPADDRESS1, m_cIPAdd);
	DDX_Control(pDX, IDC_CHECK_HEX, m_cHex);
	DDX_Control(pDX, IDC_ED_COM, m_cComData);
	DDX_Control(pDX, IDC_ED_NET, m_cNetData);
	DDX_Control(pDX, IDC_COMBO_COM, m_cCom);
	DDX_Control(pDX, IDC_COMBO_BAUDRATE, m_cBaudRate);
	DDX_Control(pDX, IDOPEN, m_cBnOpen);
	DDX_Text(pDX, IDC_ComStatus, m_vComStatus);
	DDX_Text(pDX, IDC_ED_NET, m_vNetData);
	DDX_Text(pDX, IDC_ED_COM, m_vComData);
	DDX_Text(pDX, IDC_COMLEN, m_vComDataLen);
	DDX_Text(pDX, IDC_EDIT_PORT, m_vPort);
	DDX_Text(pDX, IDC_NETStatus, m_vNetStatus);
	DDX_Text(pDX, IDC_NETLEN, m_vNetDataLen);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CTcpComDlg, CDialog)
	//{{AFX_MSG_MAP(CTcpComDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_CBN_SELCHANGE(IDC_COMBO_COM, OnSelchangeComboCom)
	ON_CBN_SELCHANGE(IDC_COMBO_BAUDRATE, OnSelchangeComboBaudrate)
	ON_BN_CLICKED(IDOPEN, OnOpen)
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_CHECK_HEX, OnCheckHex)
	ON_BN_CLICKED(IDC_CHECK_0x, OnCHECK0x)
	ON_BN_CLICKED(IDC_CHECK_SG, OnCheckSg)
	ON_BN_CLICKED(ID_CLEAR, OnClear)
	ON_WM_SIZE()
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTcpComDlg message handlers

BOOL CTcpComDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
/*
	m_cCom.SetCurSel(2);
	m_cBaudRate.SetCurSel(1);
	m_cHex.SetCheck(TRUE);
	m_cIPAdd.SetAddress(127,0,0,1);
*/
	EI_vSysInit();
//    SetTimer(CHECK_TIMER,5000,NULL);	
//	CTcpComDlg::OnOpen();
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CTcpComDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CTcpComDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CTcpComDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CTcpComDlg::OnCancel() 
{
	// TODO: Add extra cleanup here
	if( IDYES == MessageBox("        ȷ��Ҫ�˳���",0,MB_YESNOCANCEL) )
    {
        CDialog::OnCancel();
    }
}

void CTcpComDlg::OnOK() 
{
	// TODO: Add extra validation here
	
	CDialog::OnOK();
}

void CTcpComDlg::OnSelchangeComboCom() 
{
	// TODO: Add your control notification handler code here
	CString sIniData;
	
	switch(m_cCom.GetCurSel())
    {
    case 0:
        {
            memcpy(gacCom, "COM1", 4);
        }
        break;
    case 1:
        {
            memcpy(gacCom, "COM2", 4);
        }
        break;
    case 2:
        {
            memcpy(gacCom, "COM3", 4);			
        }
        break;
    case 3:
        {
            memcpy(gacCom, "COM4", 4);			
        }
        break;
    case 4:
        {
            memcpy(gacCom, "COM5", 4);			
        }
        break;
    case 5:
        {
            memcpy(gacCom, "COM6", 4);			
        }
        break;
    case 6:
        {
            memcpy(gacCom, "COM7", 4);			
        }
        break;
    default:
        {
            memcpy(gacCom, "COM3", 4);
        }
        break;
    }  
	sIniData.Format("%d",m_cCom.GetCurSel());
	WritePrivateProfileString("COM","COM",sIniData,".\\TcpComConfig.ini");
	
}

void CTcpComDlg::OnSelchangeComboBaudrate() 
{
	// TODO: Add your control notification handler code here
	CString sIniData;

	switch(m_cBaudRate.GetCurSel())
    {
    case 0:
        giBaudRate = 300;
        break;
    case 1:
        giBaudRate = 1200;
        break;
    case 2:
        giBaudRate = 9600;
        break;
    case 3:
        giBaudRate = 38400;
        break;
    case 4:
        giBaudRate = 57600;
        break;
    case 5:
        giBaudRate = 115200;
        break;
    default:
        giBaudRate = 115200;
        break;
    } 
	sIniData.Format("%d",m_cBaudRate.GetCurSel());
	WritePrivateProfileString("COM","BaudRate",sIniData,".\\TcpComConfig.ini");
		
}

void CTcpComDlg::OnOpen() 
{
	// TODO: Add your control notification handler code here
	char cRet;

	cRet = EI_cOpenCom();
				
/*
	cRet = EI_cTCPOpen();
	if(m_cSingle.GetCheck())
	{
		EI_cOpenCom();
	}
	else
	{
		if(cRet == 0)
		{
			cRet = EI_cOpenCom();
			if(cRet != 0)
			{
				cRet = EI_cTCPOpen();
				if((cRet ==0)&&(gbSockClientConnectFlag==true)&&(gbComOpenFlag==true))
					gbSystemRunFlag = true;
				else
					gbSystemRunFlag = false;
			}
		}
	}
*/
}

char CTcpComDlg::EI_cOpenCom()
{
    LONG    lLastError = ERROR_SUCCESS;
    CString sComStatus;
    CString sComNo;
    
	gbSystemRunFlag = false;
    gbComOpenFlag = false;
    m_cBnOpen.GetWindowText(sComStatus);  
    if(0 == memcmp(sComStatus,"�ر�",strlen("�ر�")))
    {
		m_cCom.EnableWindow(TRUE);
		m_cBaudRate.EnableWindow(TRUE);		
		m_cBnOpen.SetWindowText("��");
        m_vComStatus = "�����ѹر�";
        UpdateData(false);    
        objSerial.Close();  
        KillTimer(COM_TIMER);
        return 0;
    }
    
    m_cCom.GetWindowText(sComNo);
    memcpy(gacCom,sComNo,4);
    if (gacCom == NULL || giBaudRate == 0)
    {
        m_vComStatus = "���ڲ�������";
        UpdateData(false);    
        return 1;
    }
	
    lLastError = objSerial.Open(gacCom);
    if (lLastError != ERROR_SUCCESS)
    {
        m_vComStatus.Format("%s%s%s","����",gacCom,"��ʧ��1");
        UpdateData(false);    
        objSerial.Close();            
        return 1;
    }
    
    lLastError = objSerial.Setup(CSerial::EBaudrate(giBaudRate), CSerial::EData8, CSerial::EParNone, CSerial::EStop1);
    if (lLastError != ERROR_SUCCESS)
    {
        m_vComStatus.Format("%s%s%s","����",gacCom,"��ʧ��2");
        UpdateData(false);    
        objSerial.Close();            
        return 1;
    }
    
    // Set to ReadBlocking mode
    objSerial.SetupReadTimeouts(CSerial::EReadTimeoutBlocking);
	
    gbComOpenFlag = true;
    SetTimer(COM_TIMER,200,NULL);
	m_cCom.EnableWindow(FALSE);
	m_cBaudRate.EnableWindow(FALSE);
    m_cBnOpen.SetWindowText("�ر�");
	m_vComStatus.Format("%s%s%s","����",gacCom,"�Ѵ�");
//    m_vComStatus = "�����Ѵ�";
    UpdateData(false);	
	return 0;
}

char CTcpComDlg::EI_cTCPOpen()
{
	SOCKADDR_IN addrSrv;
    DWORD       dwAddress;
    char        pStr[20];
    CString     sIPAddress,sPort;
    u_short     usPort;
	CString     sText;

    m_cBnOpen.GetWindowText(sText);
	if((false == gbSockClientConnectFlag))//&&(sText=="��")
    {
        m_cIPAdd.GetAddress(dwAddress);
        itoa(dwAddress,pStr,10);
        sIPAddress.Format("%d.%d.%d.%d"  ,dwAddress/16777216            \
                                        ,(dwAddress%16777216)/65536     \
                                        ,(dwAddress%65536)/256          \
                                        ,(dwAddress%256) );
        
		// ˢ�¼����˿� 
        m_cPort.GetWindowText(sPort); 
        m_vPort = sPort; 

		WritePrivateProfileString("Socket","ServerIP",sIPAddress,".\\TcpComConfig.ini");
		WritePrivateProfileString("Socket","PORT",sPort,".\\TcpComConfig.ini");
		
        // ��ȡ��ˢ�·������˿�
        m_cPort.GetWindowText(sPort);
        m_vPort = sPort;
        usPort = (u_short)atoi(sPort); 
        UpdateData(false);
		
        SockClient = socket(AF_INET,SOCK_STREAM,0);  
        addrSrv.sin_addr.S_un.S_addr = inet_addr(sIPAddress);
        addrSrv.sin_family           = AF_INET;
        addrSrv.sin_port             = htons(usPort);
		
        if(connect(SockClient,(SOCKADDR*)&addrSrv,sizeof(SOCKADDR)))
        {
            closesocket(SockClient);
			gbSystemRunFlag = false;
            gbSockClientConnectFlag = false;
//            m_cBnOpen.SetWindowText("��");
//            MessageBox("TCP������������");
			m_vNetStatus = "������������";
			UpdateData(false);
			return 1;			
        }
        else
        {
            gbSockClientConnectFlag = true;
//            m_cBnOpen.SetWindowText("�ر�");
            SetTimer(NET_TIMER,CLIENT_RECV_TIME,NULL);
			m_cIPAdd.EnableWindow(FALSE);
			m_cPort.EnableWindow(FALSE);
			m_vNetStatus = "�����ӷ�����";
			UpdateData(false);
			return 0;			
        }
    }
    else
    {
		m_cIPAdd.EnableWindow(TRUE);
		m_cPort.EnableWindow(TRUE);
        closesocket(SockClient);
        KillTimer(NET_TIMER);
        gbSockClientConnectFlag = false;
		gbSystemRunFlag = false;
//        m_cBnOpen.SetWindowText("��");
		m_vNetStatus = "�ѶϿ�������";
		UpdateData(false);
		return 0;		
    }
}

void CTcpComDlg::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	long lRet;
    long lShowNum,i;
    char szShowStr[10];
    DWORD dwReadLen,dwBufferLen = 0,dwWriteLen;
	char  acRecvData[3096];
	char  acFileTemp[3096];
	CString sShowStr,sFileTemp,sStatus;
	char acCurDate[50];
	char acCurTime[50];

    memset(acRecvData,0,sizeof(acRecvData));
    memset(acCurDate,0,sizeof(acCurDate));
    memset(acCurTime,0,sizeof(acCurTime));
    if(nIDEvent == COM_TIMER)
	{
		dwBufferLen = objSerial.GetInBufferCount();
		lRet = objSerial.Read(acRecvData,dwBufferLen,&dwReadLen,0,100);
		//=========================================
		if(dwReadLen > 0)
		{
//			m_vComData += "0x88";
			
			if(acRecvData[0]==(char)0x88)
			{
				m_vComData += "0x89";
				if((false == gbSockClientConnectFlag))//&&(sText=="��")
					EI_cTCPOpen();
				return;
			}
			if(acRecvData[0]==(char)0x99)
			{
				if((true == gbSockClientConnectFlag))//&&(sText=="��")
					EI_cTCPOpen();
				return;
			}
			send(SockClient,acRecvData,dwReadLen,0);	
			//=========================================
			// ����ʱ���ǩ
			_strdate(acCurDate);
			_strtime(acCurTime);
			m_vComData += "\r\nRecv COM ";
			itoa(dwReadLen,(char *)szShowStr,10);
			m_vComData += szShowStr;
			m_vComData += " Bytes Data at Time ";
			m_vComData += acCurDate;
			m_vComData += " ";
			m_vComData += acCurTime;
			m_vComData += ":\r\n";

			if(m_cHex.GetCheck())  //HEX��ʾ���յ�����
			{
				lShowNum = dwReadLen;
				i = 0;
				while(lShowNum)
				{
					sprintf(szShowStr,"%02X",acRecvData[i]);
					if(m_c0x.GetCheck())
						sFileTemp += "0x";
					if(strlen(szShowStr)>4)
						sFileTemp += (char *)&szShowStr[6];
					else
						sFileTemp += szShowStr;
					sFileTemp += " ";
					lShowNum --;
					i++;
				}     
				m_vComData += sFileTemp;
				
				sprintf(acFileTemp,"%s",sFileTemp);
				EI_vWriteDataToFile(acFileTemp,sFileTemp.GetLength(),dwReadLen,COM_DATA);
			}
			else
			{
				m_vComData += acRecvData;
				EI_vWriteDataToFile(acRecvData,dwReadLen,dwReadLen,COM_DATA);
			}
//			m_ComStatus.Format("%d",dwReadLen);
			glRecvComDataLen += dwReadLen;
			m_vComDataLen.Format("COM: %d",glRecvComDataLen);
			m_vComData += "\r\n";
			UpdateData(false);
			m_cComData.LineScroll(m_cComData.GetLineCount());
			m_cNetData.LineScroll(m_cNetData.GetLineCount());
//			m_cComData.SendMessage(WM_VSCROLL,WM_LBUTTONDOWN,0);
		}
	}
	else if (nIDEvent == NET_TIMER) 
	{
		struct timeval  timeout;
		fd_set          fdRead;
		DWORD			dwRecvLen;
		long			lRet;

		dwRecvLen = 0;
        FD_ZERO(&fdRead);                       // clear the fd_set
        FD_SET(SockClient, &fdRead);            // add socket s to the socket set
        timeout.tv_sec  = 0;
        timeout.tv_usec = 50;
		
        if (select(SockClient+1, &fdRead, NULL, NULL, &timeout) <= 0)
        {
            return;
        }
		dwRecvLen = recv(SockClient, acRecvData, sizeof(acRecvData), 0);
		if( dwRecvLen == SOCKET_ERROR )
        {
            closesocket(NET_TIMER);
//			CTcpComDlg::OnOpen();
			CTcpComDlg::EI_cTCPOpen();
		}			
		else if(dwRecvLen > 1)
        {
			//==================send data to spp =======================
			objSerial.Purge();
			lRet = objSerial.Write(acRecvData,dwRecvLen,&dwWriteLen,0,10000);
			objSerial.Flush();
			//========================================================
			// ����ʱ���ǩ
			_strdate(acCurDate);
			_strtime(acCurTime);
			m_vNetData += "\r\nRecv TCP ";
			itoa(dwRecvLen,(char *)szShowStr,10);
			m_vNetData += szShowStr;
			m_vNetData += " Bytes Data at Time ";
			m_vNetData += acCurDate;
			m_vNetData += " ";
			m_vNetData += acCurTime;
			m_vNetData += ":\r\n";
			
			if(m_cHex.GetCheck())  //HEX��ʾ���յ�����
			{
				lShowNum = dwRecvLen;
				i = 0;
				while(lShowNum)
				{
					sprintf(szShowStr,"%02X",acRecvData[i]);
					if(m_c0x.GetCheck())
						sFileTemp += "0x";
					if(strlen(szShowStr)>4)
						sFileTemp += (char *)&szShowStr[6];
					else
						sFileTemp += szShowStr;
					sFileTemp += " ";
					lShowNum --;
					i++;
				} 
				m_vNetData += sFileTemp;
				sprintf(acFileTemp,"%s",sFileTemp);
				EI_vWriteDataToFile(acFileTemp,sFileTemp.GetLength(),dwRecvLen,NET_DATA);				
			}
			else
			{
				m_vNetData += acRecvData;
				EI_vWriteDataToFile(acRecvData,dwRecvLen,dwRecvLen,NET_DATA);
			}
			glRecvNetDataLen += dwRecvLen;
			m_vNetDataLen.Format("TCP: %d",glRecvNetDataLen);
			m_vNetData += "\r\n";
			UpdateData(false);
			m_cComData.LineScroll(m_cComData.GetLineCount());
			m_cNetData.LineScroll(m_cNetData.GetLineCount());

//			if(gbSocketRecReopenFlag)
//			{
//				OnOpen();
//				Sleep(1000);
//				OnOpen();
//			}
		}		
	}
	else if(nIDEvent==CHECK_TIMER)
	{
		
		m_cBnOpen.GetWindowText(sStatus);  
		if(0 == memcmp(sStatus,"��",strlen("��")))
		{
			gbSystemRunFlag = false;
			gbSocketRecReopenFlag = false;
			gbComOpenFlag = false;
		}
		if ((gbSystemRunFlag != true)&&(!m_cSingle.GetCheck())) 
		{
			OnOpen();
		}
	}
	else
	{
		return;
	}


	CDialog::OnTimer(nIDEvent);
}

void CTcpComDlg::EI_vSysInit()
{
//	m_cCom.SetCurSel(2);
//	m_cBaudRate.SetCurSel(1);
//	m_cHex.SetCheck(TRUE);
//	m_cIPAdd.SetAddress(127,0,0,1);	
	UINT uiRet;
	char acIP[16];
	char acPort[6];
	DWORD dwRet;
	
	uiRet =	GetPrivateProfileInt("COM","COM",2,".\\TcpComConfig.ini");
	m_cCom.SetCurSel(uiRet);
	uiRet =	GetPrivateProfileInt("COM","BaudRate",5,".\\TcpComConfig.ini");
	m_cBaudRate.SetCurSel(uiRet);

	dwRet = GetPrivateProfileString("Socket","ServerIP","127.0.0.1",acIP,sizeof(acIP),".\\TcpComConfig.ini");
	m_cIPAdd.SetWindowText(acIP);
	dwRet = GetPrivateProfileString("Socket","PORT","8000",acPort,sizeof(acPort),".\\TcpComConfig.ini");
	m_cPort.SetWindowText(acPort);
	m_vPort = acPort;
	
	uiRet =	GetPrivateProfileInt("SYSTEM","HEX",1,".\\TcpComConfig.ini");
	m_cHex.SetCheck(uiRet);
	uiRet =	GetPrivateProfileInt("SYSTEM","0x",0,".\\TcpComConfig.ini");
	m_c0x.SetCheck(uiRet);
	uiRet =	GetPrivateProfileInt("SYSTEM","Single",0,".\\TcpComConfig.ini");
	m_cSingle.SetCheck(uiRet);
	uiRet =	GetPrivateProfileInt("SYSTEM","REOPEN",0,".\\TcpComConfig.ini");
//	if(uiRet)
//		gbSocketRecReopenFlag = true;
//	else
		gbSocketRecReopenFlag = false;
	
	m_vComDataLen = "COM: 0";
	m_vNetDataLen = "TCP: 0";
	UpdateData(false);
	
	
}


void CTcpComDlg::OnCheckHex() 
{
	// TODO: Add your control notification handler code here
	CString sTmp;

	sTmp.Format("%d",m_cHex.GetCheck());
	WritePrivateProfileString("SYSTEM","HEX",sTmp,".\\TcpComConfig.ini");

}

void CTcpComDlg::OnCHECK0x() 
{
	// TODO: Add your control notification handler code here
	CString sTmp;
	
	sTmp.Format("%d",m_c0x.GetCheck());
	WritePrivateProfileString("SYSTEM","0x",sTmp,".\\TcpComConfig.ini");
	
}

void CTcpComDlg::OnCheckSg() 
{
	// TODO: Add your control notification handler code here
	CString sTmp;
	
	sTmp.Format("%d",m_cSingle.GetCheck());
	WritePrivateProfileString("SYSTEM","Single",sTmp,".\\TcpComConfig.ini");
	
}

// bFlag = false :COM data;bFlag = True :Tcp data;
void CTcpComDlg::EI_vWriteDataToFile(char* sData,DWORD dwDataLenght,DWORD dwRecvDataLenght,bool bFlag)
{
	CFile fFile;
    SYSTEMTIME CurTime;
    CString sFileName,sRecTime;
	char acFormatData[5000];
	
	memset(acFormatData,'\0',sizeof(acFormatData));
	GetLocalTime(&CurTime);
	if(bFlag == COM_DATA)
	{
		sprintf(acFormatData,"Receive %d bytes data from SPP(COM) at %04d-%02d-%02d %02d:%02d:%02d  :\r\n%s \r\n\r\n"  
				,dwRecvDataLenght,CurTime.wYear,CurTime.wMonth,CurTime.wDay,CurTime.wHour
				,CurTime.wMinute,CurTime.wSecond,sData);
	}
    else
	{
		sprintf(acFormatData,"Receive %d bytes data from epay(TCP) at %04d-%02d-%02d %02d:%02d:%02d :\r\n%s \r\n\r\n" 
				,dwRecvDataLenght,CurTime.wYear,CurTime.wMonth,CurTime.wDay,CurTime.wHour
				,CurTime.wMinute,CurTime.wSecond,sData);
	}

    sFileName.Format("%04d-%02d-%02d.log",CurTime.wYear,CurTime.wMonth,CurTime.wDay);

    if(fFile.Open(sFileName, CFile::modeCreate|CFile::modeWrite|CFile::modeNoTruncate))
    {
		fFile.SeekToEnd();
		fFile.Write(acFormatData,strlen(acFormatData));
        fFile.Close();		
    }    	
}

/*
void CFile_DemoDlg::OnSize(UINT nType, int cx, int cy) 
{
	CDialog::OnSize(nType, cx, cy);
	
	// TODO: Add your message handler code here
    if(bFirstRunFlag)
    {
        CRect rcWindowRect,rcFileContentRect;
        
        GetWindowRect(rcWindowRect);
        m_FileContentCtrl.GetWindowRect(rcFileContentRect);
		
        rcFileContentRect.right     = rcWindowRect.right - rcWindowRect.left - 20;
        rcFileContentRect.bottom    = rcWindowRect.bottom - rcWindowRect.top - 40;
		//        rcFileContentRect.left      = rcWindowRect.left;
		//        rcFileContentRect.top       = rcWindowRect.top;
        rcFileContentRect.left      = 11;
        rcFileContentRect.top       = 39;
        
		/ *
        m_FileContentStr.Format("L%d,R%d,T%d,B%d",rcFileContentRect.left
		,rcFileContentRect.right
		,rcFileContentRect.top
		,rcFileContentRect.bottom);
        
		  UpdateData(false);
		* /
        rcFileContentRect.SetRect(rcFileContentRect.left
			,rcFileContentRect.top
			,rcFileContentRect.right
			,rcFileContentRect.bottom);
		
		m_FileContentCtrl.MoveWindow(rcFileContentRect);
    }
    else
    {
        bFirstRunFlag = true;        
    }
	
}

*/

void CTcpComDlg::OnClear() 
{
	// TODO: Add your control notification handler code here
	if( IDYES == MessageBox("        ���������ʾ���ݣ� ",0,MB_YESNOCANCEL) )
    {
		m_vComData.Empty();
		m_vNetData.Empty();
		m_vComDataLen = "0";
		m_vNetDataLen = "0";
		UpdateData(false);
    }	
}

void CTcpComDlg::OnSize(UINT nType, int cx, int cy) 
{
	CDialog::OnSize(nType, cx, cy);
	
	// TODO: Add your message handler code here
/*
    if(bFirstRunFlag)
    {
        CRect rcWindowRect,rcFileContentRect;
        
        GetWindowRect(rcWindowRect);
        m_FileContentCtrl.GetWindowRect(rcFileContentRect);
		
        rcFileContentRect.right     = rcWindowRect.right - rcWindowRect.left - 20;
        rcFileContentRect.bottom    = rcWindowRect.bottom - rcWindowRect.top - 40;
		//        rcFileContentRect.left      = rcWindowRect.left;
		//        rcFileContentRect.top       = rcWindowRect.top;
        rcFileContentRect.left      = 11;
        rcFileContentRect.top       = 39;
        
		/ *
			m_FileContentStr.Format("L%d,R%d,T%d,B%d",rcFileContentRect.left
			,rcFileContentRect.right
			,rcFileContentRect.top
			,rcFileContentRect.bottom);
        
		UpdateData(false);
		* /
			rcFileContentRect.SetRect(rcFileContentRect.left
			,rcFileContentRect.top
			,rcFileContentRect.right
			,rcFileContentRect.bottom);
		
		m_FileContentCtrl.MoveWindow(rcFileContentRect);
    }
    else
    {
        bFirstRunFlag = true;        
    }	*/

}

void CTcpComDlg::OnButton1() 
{
	// TODO: Add your control notification handler code here
	EI_cTCPOpen();
}
